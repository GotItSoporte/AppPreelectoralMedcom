import React from "react";
import { Home } from "./Home";

export const HomeLoad = () => {
  return <Home />;
};
