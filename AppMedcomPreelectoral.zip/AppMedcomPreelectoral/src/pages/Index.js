export {Home} from './home'
export {Wall} from './wall'
export {Register} from './register'
