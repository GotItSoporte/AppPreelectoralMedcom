import React from "react";
import { Wall } from "./Wall";

export const WallLoad = () => {
  return <Wall />;
};
