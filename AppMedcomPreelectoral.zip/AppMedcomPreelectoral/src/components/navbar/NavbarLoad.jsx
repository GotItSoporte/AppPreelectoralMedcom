import React from "react";
import { Navbar } from "./navbar";

export const NavbarLoad = () => {
  return <Navbar />;
};
