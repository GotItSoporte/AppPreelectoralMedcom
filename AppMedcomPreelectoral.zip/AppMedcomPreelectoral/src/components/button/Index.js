export { ButtonLoad as Button} from "./ButtonLoad";

