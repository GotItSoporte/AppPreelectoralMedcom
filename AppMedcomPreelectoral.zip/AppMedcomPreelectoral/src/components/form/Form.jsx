import React from "react";
import PropTypes from "prop-types";
import { Dropdown, Button } from "../../components";

export const Form = ({
  
  setMostrarFormulario,
  //variables
  selectedPosicion,
  setSelectedPosicion,
  listPosicion,
  selectedCorporacion,
  setSelectedCorporacion,
  listCorporacion,
  selectedPartido,
  setSelectedPartido,
  listPartido,
  selectedProvincia,
  setSelectedProvincia,
  listProvincia,
  selectedDistrito,
  listDistrito,
  setSelectedDistrito,
  selectedCircuito,
  setSelectedCircuito,
  listCircuito,
}) => {
  return (
    <div className="p-10 w-full sm:w-3/4 lg:w-2/3  bg-gray-900 border-4 border-red-500 rounded-xl mx-auto overflow-y-scroll h-2/3 sm:h-fit" id="ventanaFormulario">
      <div className="flex justify-end" onClick={()=>setMostrarFormulario(false)}>
        <Button type='Principal' name='Cerrar' rute=''/>
      </div>

      <h1 className="text-5xl font-bold tracking-tight text-white text-center mb-10 lg:mx-0">
        REGISTRAR CANDIDATO
      </h1>
      <form className="lg:mx-36">
        <div className="grid lg:grid-cols-3 md:gap-6">
          <div className="relative z-0 w-full mb-6 group">
            <input
              type="text"
              name="nombre"
              id="nombre"
              className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
              placeholder=" "
              required
            />
            <label
              htmlFor="nombre"
              className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
            >
              Nombre
            </label>
          </div>
          <div className="relative z-0 w-full mb-6 group">
            <input
              type="number"
              name="id"
              id="id"
              className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer"
              placeholder=" "
              required
            />
            <label
              htmlFor="id"
              className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:left-0 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6"
            >
              Id (123-456-7890)
            </label>
          </div>
          <div className="flex justify-around lg:justify-center sm:space-x-10">
            <Dropdown
              selectedOption={selectedPosicion}
              setSelectedOption={setSelectedPosicion}
              setList={listPosicion}
            />
            <Dropdown
              selectedOption={selectedPartido}
              setSelectedOption={setSelectedPartido}
              setList={listPartido}
            />
          </div>
        </div>

        <h1 className="text-3xl font-bold tracking-tight text-white text-center mt-10 lg:mx-0">
          DATOS COMPLEMENTARIOS 
        </h1>
        <div className="grid grid-cols-1 sm:grid-cols-4 lg:grid-cols-4 md:gap-6 mt-5 mx-auto w-fit gap-4 text-center  ">
        <Dropdown
            selectedOption={selectedCorporacion}
            setSelectedOption={setSelectedCorporacion}
            setList={listCorporacion}
          />
          <Dropdown
            selectedOption={selectedProvincia}
            setSelectedOption={setSelectedProvincia}
            setList={listProvincia}
          />
          
          <Dropdown
            selectedOption={selectedDistrito}
            setSelectedOption={setSelectedDistrito}
            setList={listDistrito}
          />
          <Dropdown
            selectedOption={selectedCircuito}
            setSelectedOption={setSelectedCircuito}
            setList={listCircuito}
          />
        </div>
        <div className="flex justify-center mt-10 cursor-pointer">
         <Button type='Principal' name='Registrar' rute="" />
        </div>
      </form>
    </div>
  );
};

Form.propTypes = {
  setMostrarFormulario: PropTypes.func.isRequired,
  selectedPosicion: PropTypes.string.isRequired,
  setSelectedPosicion: PropTypes.func.isRequired,
  listPosicion: PropTypes.array.isRequired,
  selectedCorporacion: PropTypes.string.isRequired,
  setSelectedCorporacion: PropTypes.func.isRequired,
  listCorporacion: PropTypes.array.isRequired,
  selectedPartido: PropTypes.string.isRequired,
  setSelectedPartido: PropTypes.func.isRequired,
  listPartido: PropTypes.array.isRequired,
  selectedProvincia: PropTypes.string.isRequired,
  setSelectedProvincia: PropTypes.func.isRequired,
  listProvincia: PropTypes.array.isRequired,
  selectedDistrito: PropTypes.string.isRequired,
  listDistrito: PropTypes.array.isRequired,
  setSelectedDistrito: PropTypes.func.isRequired,
  selectedCircuito: PropTypes.string.isRequired,
  setSelectedCircuito: PropTypes.func.isRequired,
  listCircuito: PropTypes.array.isRequired,
};
