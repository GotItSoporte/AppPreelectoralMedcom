import React, { useState } from "react";
import { Form } from "./Form";
import PropTypes from "prop-types";

export const FormLoad = ({ setMostrar }) => {
  //Seleccion
  const [selectedPosicion, setSelectedPosicion] = useState("Posicion...");
  const [selectedCorporacion, setSelectedCorporacion] =
    useState("Corporacion...");
  const [selectedPartido, setSelectedPartido] = useState("Partido...");
  const [selectedProvincia, setSelectedProvincia] = useState("Provincia...");
  const [selectedDistrito, setSelectedDistrito] = useState("Distrito...");
  const [selectedCircuito, setSelectedCircuito] = useState("Circuito...");

  //Listas
  const [listPosicion] = useState([
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
  ]);
  const [listCorporacion] = useState(["Presidentes", "Alcaldes", "Diputados"]);
  const [listPartido] = useState(["RM", "PRD", "CD", "PAM"]);
  const [listProvincia] = useState(["NACIONAL", "BOCAS DEL TORO", "COCLÉ"]);
  const [listDistrito] = useState(["PENONOMÉ", "COLÓN", "DAVID"]);
  const [listCircuito] = useState([
    "CIRCUITO 4-1",
    "CIRCUITO 4-2",
    "CIRCUITO 4-3",
  ]);

  return (
    <Form
      selectedPosicion={selectedPosicion}
      setSelectedPosicion={setSelectedPosicion}
      listPosicion={listPosicion}
      selectedCorporacion={selectedCorporacion}
      setSelectedCorporacion={setSelectedCorporacion}
      listCorporacion={listCorporacion}
      selectedPartido={selectedPartido}
      setSelectedPartido={setSelectedPartido}
      selectedProvincia={selectedProvincia}
      setSelectedProvincia={setSelectedProvincia}
      listProvincia={listProvincia}
      selectedDistrito={selectedDistrito}
      listDistrito={listDistrito}
      setSelectedDistrito={setSelectedDistrito}
      selectedCircuito={selectedCircuito}
      setSelectedCircuito={setSelectedCircuito}
      listCircuito={listCircuito}
      listPartido={listPartido}
      setMostrarFormulario={setMostrar}
    />
  );
};

FormLoad.propTypes = {
  setMostrar: PropTypes.func.isRequired,
};
